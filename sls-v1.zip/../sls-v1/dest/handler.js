'use strict';

require('babel-polyfill');

var _apex = require('apex.js');

var _apex2 = _interopRequireDefault(_apex);

var _axios = require('axios');

var _axios2 = _interopRequireDefault(_axios);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

var sleep = function sleep(time) {
  return new Promise(function (resolve, reject) {
    console.log(time);
    setTimeout(function () {
      resolve(time + ' wait done.');
    }, time);
  });
};

module.exports.hello = function (event, context, cb) {
  _asyncToGenerator(regeneratorRuntime.mark(function _callee() {
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.t0 = console;
            _context.next = 3;
            return sleep(1000);

          case 3:
            _context.t1 = _context.sent;

            _context.t0.log.call(_context.t0, _context.t1);

            _context.t2 = console;
            _context.next = 8;
            return sleep(500);

          case 8:
            _context.t3 = _context.sent;

            _context.t2.log.call(_context.t2, _context.t3);

            cb(null, { message: 'Go Serverless v1.0! Your function executed successfully!', event: event });

          case 11:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }))();
};

module.exports.lambda = (0, _apex2.default)(function (e) {
  console.log('fetching %d urls', e.urls.length);
  return Promise.all(e.urls.map(function () {
    var _ref2 = _asyncToGenerator(regeneratorRuntime.mark(function _callee2(url) {
      return regeneratorRuntime.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              console.log('fetching %s', url);
              _context2.next = 3;
              return _axios2.default.get(url);

            case 3:
              _context2.t0 = _context2.sent.status;
              _context2.t1 = url;
              return _context2.abrupt('return', {
                status: _context2.t0,
                url: _context2.t1
              });

            case 6:
            case 'end':
              return _context2.stop();
          }
        }
      }, _callee2, undefined);
    }));

    return function (_x) {
      return _ref2.apply(this, arguments);
    };
  }()));
});